template <> struct Traits<Build>
{
    enum {LIBRARY};
    static const unsigned int MODE = LIBRARY;

    enum {IA32};
    static const unsigned int ARCH = IA32;

    enum {PC};
    static const unsigned int MACH = PC;
};
